self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ec8548675d41bcad9f17",
    "url": "/vue3-News/css/about.4ed269e0.css"
  },
  {
    "revision": "5e136ffe3df255b4f540",
    "url": "/vue3-News/css/app.73bd0497.css"
  },
  {
    "revision": "92609100f5136f7455fd",
    "url": "/vue3-News/css/narkdowninfo.58f0454b.css"
  },
  {
    "revision": "cf140ad1843144f1a201",
    "url": "/vue3-News/css/pixelartinfo.634ba707.css"
  },
  {
    "revision": "14f17dec107316c01dc9",
    "url": "/vue3-News/css/reactinfo.3e8b3d64.css"
  },
  {
    "revision": "451630803f340c672643",
    "url": "/vue3-News/css/todosinfo.da3754f3.css"
  },
  {
    "revision": "7fd4a85903d9d0018e99",
    "url": "/vue3-News/css/vueinfo.4a7222d2.css"
  },
  {
    "revision": "82b9c7a5a3f405032b1db71a25f67021",
    "url": "/vue3-News/img/logo.82b9c7a5.png"
  },
  {
    "revision": "30a220b6bf42446779d11782963519e1",
    "url": "/vue3-News/index.html"
  },
  {
    "revision": "ec8548675d41bcad9f17",
    "url": "/vue3-News/js/about.df8c397d.js"
  },
  {
    "revision": "5e136ffe3df255b4f540",
    "url": "/vue3-News/js/app.29a1d3dc.js"
  },
  {
    "revision": "c8e1ec7ca6405ac9db97",
    "url": "/vue3-News/js/chunk-vendors.5149e90f.js"
  },
  {
    "revision": "92609100f5136f7455fd",
    "url": "/vue3-News/js/narkdowninfo.35dcd264.js"
  },
  {
    "revision": "cf140ad1843144f1a201",
    "url": "/vue3-News/js/pixelartinfo.21a5ffc4.js"
  },
  {
    "revision": "14f17dec107316c01dc9",
    "url": "/vue3-News/js/reactinfo.e9233f2a.js"
  },
  {
    "revision": "451630803f340c672643",
    "url": "/vue3-News/js/todosinfo.9fc87537.js"
  },
  {
    "revision": "7fd4a85903d9d0018e99",
    "url": "/vue3-News/js/vueinfo.8ec998a0.js"
  },
  {
    "revision": "74899d989cff1a295601bd08d6e6170f",
    "url": "/vue3-News/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/vue3-News/robots.txt"
  }
]);