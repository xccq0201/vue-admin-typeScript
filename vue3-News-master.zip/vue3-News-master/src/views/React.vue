<template>
  <div>
    <ReactInfo />
  </div>
</template>

<script>
// @ is an alias to /src
import ReactInfo from "@/components/ReactInfo.vue";

export default {
  name: "react",
  components: {
    ReactInfo,
  },
};
</script>
