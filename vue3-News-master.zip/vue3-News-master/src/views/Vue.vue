<template>
  <div>
    <VueInfo />
  </div>
</template>

<script>
// @ is an alias to /src
import VueInfo from "@/components/VueInfo.vue";

export default {
  name: "vue",
  components: {
    VueInfo,
  },
};
</script>
